from html import escape

def format_job(job):
    title = escape(job["title"])
    snippet = escape(job.get("snippet",""))
    source = escape(job.get("source",""))
    url = job["url"]
    return (
        f"🆕 <b>{title}</b>\n\n"
        f"📌 <b>خلاصه:</b> {snippet}\n\n"
        f"🌐 <b>منبع:</b> {source}\n"
        f"🔗 <a href=\"{url}\">مشاهده آگهی</a>\n\n"
        f"#استخدام #بهداشت_محیط"
    )
