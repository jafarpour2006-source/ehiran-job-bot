import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHANNEL_ID = os.getenv("TELEGRAM_CHANNEL_ID", "")
SERPER_API_KEY = os.getenv("SERPER_API_KEY", "")
SEARCH_INTERVAL_HOURS = float(os.getenv("SEARCH_INTERVAL_HOURS", "3"))
MAX_RESULTS_PER_QUERY = int(os.getenv("MAX_RESULTS_PER_QUERY", "10"))
DB_PATH = os.getenv("DB_PATH", "jobs.db")

if not TELEGRAM_BOT_TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN تنظیم نشده است.")
if not TELEGRAM_CHANNEL_ID:
    raise RuntimeError("TELEGRAM_CHANNEL_ID تنظیم نشده است.")
if not SERPER_API_KEY:
    raise RuntimeError("SERPER_API_KEY تنظیم نشده است.")
